#!/bin/sh
cd bin
rm Nini.dll.so
rm DotNetOpen*.dll.so
rm Ionic.Zip.dll.so
rm Newtonsoft.Json.dll.so
rm C5.dll.so
rm CSJ2K.dll.so
rm Npgsql.dll.so
rm RestSharp.dll.so
rm Mono*.dll.so
rm MySql*.dll.so
rm OpenMetaverse*.dll.so
rm OpenSim*.dll.so
rm OpenSim*.exe.so
rm Robust*.exe.so
cd ..